	private static final String AWS_ACCESS_KEY_ID = "AKIAZBQE345LKPTEAHQD";
	private static final String AWS_SECRET_ACCESS_KEY = "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";
